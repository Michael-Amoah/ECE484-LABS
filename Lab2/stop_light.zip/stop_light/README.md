Name: Michael Amoah, Jose Salinas 
Assignment: Lab2 
Date: Feb 9, 2023

Attachments:
- README.txt
- stop_light_fixed.c
- compile_lines.py: script that compiles and runs stop_light_fixed.c

Compile Instructions:
- python ./compile_lines stop_light_fixed.c comXX

